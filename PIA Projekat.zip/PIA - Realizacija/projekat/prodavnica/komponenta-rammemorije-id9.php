<!DOCTYPE html>
<html>
<head>
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="icon" href="/projekat/slike/computer.png">
 <title>WhiTex Web Store</title>
 <link rel="stylesheet" type="text/css" href="/projekat/navigacijaGore.css" />
 <link rel="stylesheet" type="text/css" href="/projekat/prodavnica/izgledProdavnica.css" />
 <style type="text/css">
   a:hover, a:visited, a:link, a:active
   {
    text-decoration: none;
   }
 </style>
</head>

<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projekat";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
 } 

?>

<?php
$sql1 = "SELECT * FROM ram ORDER BY Cena ASC";
$result1 = $conn->query($sql1)->fetch_object();
?> 


 <div id="slikaGore" align="center"><a href="/projekat/index.php">
 <img align="center" src="/projekat/slike/header.jpg"></a>
 </div>

 <center><div class="topnav" id="myTopnav">
   <b>
   <a href="/projekat/index.php">Pocetna</a>
   <a href="/projekat/konf/konf.php">Kofigurator</a>
   <a href="/projekat/info/kontakt.php">Kontakt</a>
   <a href="/projekat/info/nama.php">O nama</a></b>

  <div class="vreme" align="right">
      <i><script type="text/javascript">
        var m_names = new Array("Januar", "Februar", "Mart", "April", "Maj", "Jun", "Jul", "Avgust", "Septembar", "Octobar", "Novembar", "Decembar");
        var d_names = new Array("Nedelja", "Ponedeljak", "Utorak", "Sreda", "Cetvrtak", "Petak", "Subota");
        
        var currentTime = new Date()
        var day = currentTime.getDay()
        var month = currentTime.getMonth() + 1
        var date = currentTime.getDate()
        var year = currentTime.getFullYear()
        document.write( d_names[day] + ", " + date + " " + m_names[month] + " " + year + ", ")
        var currentTime = new Date()
        var hours = currentTime.getHours()
        var minutes = currentTime.getMinutes()
        if (minutes < 10){
        minutes = "0" + minutes
        }
        document.write(hours + ":" + minutes + " ")
        if(hours > 11){
        document.write("PM &nbsp")
        } else {
        document.write("AM &nbsp")
        }
      </script></i>
        </div>
 </div>
 <br>
 <div class="pretraga">
   <form action="izborRam.php">

     <p>
      <label for="nazivKomp">Naziv</label><br>
      <input type="text" name="naziv" id="naziv">
     </p>

     <p>
      <label for="proizvodjac">Proizvodjac</label><br>
      <select id="proizvodjac" name="proizvodjac" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="KINGSTON">KINGSTON</option>
        <option value="CORSAIR">CORSAIR</option>
        <option value="PATRIOT">PATRIOT</option>
      </select>
     </p>

      <label for="cena">Cena</label><br>
      <select id="cena" name="cena" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="1"> <500 </option>
        <option value="2"> 500-1000 </option>
        <option value="3"> 1000-2000 </option>
        <option value="4"> 2000-5000 </option>
        <option value="5"> 5000-10000 </option>
        <option value="6"> 10000-25000 </option>
        <option value="7"> 25000-50000 </option>
        <option value="8"> 50000-100000 </option>
        <option value="9"> >100000 </option>
      </select>
     </p>

     <p>
      <label for="tip">Tip</label><br>
      <select id="tip" name="tip" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="DDR2">DDR2</option>
        <option value="DDR3">DDR3</option>
        <option value="DDR4">DDR4</option>
      </select>
     </p>
    
     <p>
      <label for="takt">Takt</label><br>
      <select id="takt" name="takt" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="667MHz"> 667MHz </option>
        <option value="1333MHz"> 1333MHz </option>
        <option value="1600MHz"> 1600MHz </option>
        <option value="1866MHz"> 1866MHz </option>
        <option value="2400MHz"> 2400MHz </option>
        <option value="3000MHz"> 3000MHz </option>
      </select>
     </p>
        
	 <p>
      <label for="latencija">Latencija</label><br>
      <select id="latencija" name="latencija" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="CL5"> CL5 </option>
        <option value="CL9"> CL9 </option>
        <option value="CL10"> CL10 </option>
        <option value="CL15"> CL15 </option>
        <option value="CL16"> CL16 </option>
      </select>
     </p>

     <p>
      <label for="kapacitet">Kapacitet</label><br>
      <select id="kapacitet" name="kapacitet" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="1GB"> 1GB </option>
        <option value="2GB"> 2GB </option>
        <option value="4GB"> 4GB </option>
        <option value="8GB"> 8GB </option>
        <option value="16GB"> 16GB </option>
      </select>
     </p><br>

     <p>
       <input type="submit" value="Pretraga"></p>
       <p>
       <input type="reset"></p>
  </form>
  </div>

 <br>

 <div class="prikazKomponenti"><p>
  <i>Ukoliko se odlucite za kupovinu proizvoda, <br>molimo Vas da direktno odete na stranicu 
  <a href="/projekat/info/kontakt.php"><font color="green"><b>Kontakt</b></font></a></i>
 <?php 

   $result1 = $conn->query($sql1);

   if ($result1->num_rows > 0) {
     while($row = $result1->fetch_assoc()) {
      echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
    	echo '<center><img img height="150" width="150" src="data:image/png;base64,'. base64_encode( $row['Slika'] ).'"/><br>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
      echo "Proizvodjac: " . "<b>". $row["Proizvodjac"] . "</b>"."<br>";
      echo "Tip: " . "<b>". $row["Tip"] ."</b>". "<br>";
      echo "Takt: " . "<b>". $row["BrzinaRada"] ."</b>". "<br>";
      echo "Kapacitet: " . "<b>". $row["Kapacitet"] ."</b>". "<br>";
      echo "Latencija: " . "<b>". $row["Latencija"] ."</b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
      }}
 ?>   
 </p></div>

 <br>

 <center><div class="futer" id="futer">

   <div class="social" align="left">

      <p1>Pratite nas</p1> <br><br>
       &nbsp&nbsp<a href="/projekat/index.php""><img src="/projekat/slike/social/instagram.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/facebook.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/google-plus.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/linkedin.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/twitter.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/youtube.png"></a>
     </div>

    <div class="placanje" align="right">
      <br>
      &nbsp&nbsp<a href="/projekat/index.php"><img src="/projekat/slike/placanje/maestro.png"></a>
      <a href="/projekat/index.php"><img src="/projekat/slike/placanje/mastercard.png"></a>
      <a href="/projekat/index.php"><img src="/projekat/slike/placanje/paypal.png"></a>
      <a href="/projekat/index.php"><img src="/projekat/slike/placanje/visa.png"></a>&nbsp&nbsp
      </div>

 <hr>

<div class="sranje">
   <br><center><i>
    © 2018 WhiTex Web Store d.o.o. Sva prava zadrzana.<br>

    Cene na sajtu su iskazane u dinarima sa uracunatim porezom, a placanje se vrsi iskljucivo u dinarima.
    <br>Nastojimo da budemo sto precizniji u opisu proizvoda, prikazu slika i samih cena, ali ne mozemo garantovati da su sve informacije kompletne i bez gresaka.
    <br>Svi artikli prikazani na sajtu su deo nase ponude i ne podrazumeva da su dostupni u svakom trenutku. 
    </i></center>
 </div>

 <br>
 <p1><i><center><a href="/projekat/index.php">Kontakti ovlascenih servisa</a>&nbsp;|&nbsp;<a href="/projekat/index.php"">Uslovi koriscenja</a>&nbsp;|&nbsp;<a href="/projekat/index.php">Politika privatnosti</a>&nbsp;|&nbsp;<a href="/projekat/index.php">Zasto smo bolji od drugih</a>&nbsp;|&nbsp;<a href="/projekat/index.php">Posao</a>&nbsp;|&nbsp;
 <a href="//localhost/projekat/login/login.php"><font color="green">Login</font></a></i></p1>
 </div></center>
    
</body>
</html> 