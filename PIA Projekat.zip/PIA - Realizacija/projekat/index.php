<?php
session_start();
$_SESSION["privilegija"] = "user";
?>
<!DOCTYPE html>
<html>
<head>
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="icon" href="/projekat/slike/computer.png">
 <title>WhiTex Web Store</title>
 <link rel="stylesheet" type="text/css" href="navigacijaGore.css" />
 <style type="text/css">
   a:hover, a:visited, a:link, a:active
   {
    text-decoration: none;
   }
  </style>
</head>

<body>
	<center>
<div class="headoba"><marquee behavior="scroll" direction="left"><img src="/projekat/slike/ww.gif" width="80" height="80" alt="riba" />
	<font color="cyan"><i>Dobrodosli na WhiTex Web Store</i></font><img src="/projekat/slike/ww.gif" width="80" height="80" alt="riba" />
	</marquee></center>
</div>
<br>
<div id="slikaGore" align="center"><a href="/projekat/index.php">
   <img align="center" src="/projekat/slike/header.jpg"></a>
   </div>

 <center><div class="topnav" id="myTopnav">
  <a class="active" href="/projekat/index.php"><b>Pocetna</b></a>
  <a href="/projekat/konf/konf.php"><b>Kofigurator</b></a>
  <a href="/projekat/info/kontakt.php"><b>Kontakt</b></a>
  <a href="/projekat/info/nama.php"><b>O nama</b></a>

  <div class="vreme" align="right">
      <i><script type="text/javascript">
        var m_names = new Array("Januar", "Februar", "Mart", "April", "Maj", "Jun", "Jul", "Avgust", "Septembar", "Octobar", "Novembar", "Decembar");
        var d_names = new Array("Nedelja", "Ponedeljak", "Utorak", "Sreda", "Cetvrtak", "Petak", "Subota");
        
        var currentTime = new Date()
        var day = currentTime.getDay()
        var month = currentTime.getMonth() + 1
        var date = currentTime.getDate()
        var year = currentTime.getFullYear()
        document.write( d_names[day] + ", " + date + " " + m_names[month] + " " + year + ", ")
        var currentTime = new Date()
        var hours = currentTime.getHours()
        var minutes = currentTime.getMinutes()
        if (minutes < 10){
        minutes = "0" + minutes
        }
        document.write(hours + ":" + minutes + " ")
        if(hours > 11){
        document.write("PM &nbsp")
        } else {
        document.write("AM &nbsp")
        }
      </script></i>
        </div>
</div></center>

<br><br>

  <center><table id="izbor1">
   <tr>
    <td>&nbsp&nbsp<a href="/projekat/prodavnica/komponenta-hdd-id1"><img src="/projekat/slikeizbor/hddnova.png" style="width:150px;height:150px;"><br><center><b>Hard diskovi</b></center></a></td>
    <td>&nbsp&nbsp&nbsp<a href="/projekat/prodavnica/komponenta-dvdrom-id2"><img src="/projekat/slikeizbor/romOtvoren.png" style="width:150px;height:150px;"><br><center><b>DVD ROM</b></center></a></td>
    <td><a href="/projekat/prodavnica/komponenta-grafickekarte-id3"><img src="/projekat/slikeizbor/graficka.png" style="width:150px;height:150px;"><br><center><b>Graficke kartice</b></center></a></td>
    <td><a href="/projekat/prodavnica/komponenta-hladnjaci-id4"><img src="/projekat/slikeizbor/hladnjak.png" style="width:150px;height:150px;"><br><center><b>Hladnjaci</b></center></a></td>
    <td><a href="/projekat/prodavnica/komponenta-kucista-id5"><img src="/projekat/slikeizbor/kuciste.png" style="width:150px;height:150px;"><br><center><b>Kucista</b></center></a></td>
  </tr>
  </table></center> 

  <br><br>

  <center> <table id="izbor2">
   <tr>
    <td>&nbsp<a href="/projekat/prodavnica/komponenta-maticneploce-id6"><img src="/projekat/slikeizbor/maticna.png" style="width:150px;height:150px;"><br><center><b>Maticne ploce</b></center></a></td>
    <td>&nbsp&nbsp<a href="/projekat/prodavnica/komponenta-napajanja-id7"><img src="/projekat/slikeizbor/napajanje.png" style="width:150px;height:150px;"><br><center><b>Napajanja</b></center></a></td>
    <td>&nbsp<a href="/projekat/prodavnica/komponenta-procesori-id8"><img src="/projekat/slikeizbor/procesor.png" style="width:150px;height:150px;"><br><center><b>Procesori</b></center></a></td>
    <td>&nbsp<a href="/projekat/prodavnica/komponenta-rammemorije-id9"><img src="/projekat/slikeizbor/ram.png" style="width:150px;height:150px;"><br><center><b>RAM memorije</b></center></a></td>
    <td>&nbsp<a href="/projekat/prodavnica/komponenta-ssd-id10"><img src="/projekat/slikeizbor/ssdnovi.png" style="width:150px;height:150px;"><br><center><b>SSD</b></center></a></td>
  </tr>
 </table></center> 
 <br><br>

<center><div class="futer" id="futer">

   <div class="social" align="left">

      <p1>Pratite nas</p1> <br><br>
       &nbsp&nbsp<a href="/projekat/index.php""><img src="/projekat/slike/social/instagram.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/facebook.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/google-plus.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/linkedin.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/twitter.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/youtube.png"></a>
     </div>

   <div class="placanje" align="right">
     <br>
     &nbsp&nbsp<a href="/projekat/index.php"><img src="/projekat/slike/placanje/maestro.png"></a>
     <a href="/projekat/index.php"><img src="/projekat/slike/placanje/mastercard.png"></a>
     <a href="/projekat/index.php"><img src="/projekat/slike/placanje/paypal.png"></a>
     <a href="/projekat/index.php"><img src="/projekat/slike/placanje/visa.png"></a>&nbsp&nbsp
    </div>

 <hr>

   <div class="sranje">
     <br><center><i>
     © 2018 WhiTex Web Store d.o.o. Sva prava zadrzana.<br>
      Cene na sajtu su iskazane u dinarima sa uracunatim porezom, a placanje se vrsi iskljucivo u dinarima.
      <br>Nastojimo da budemo sto precizniji u opisu proizvoda, prikazu slika i samih cena, ali ne mozemo garantovati da su sve informacije kompletne i bez gresaka.
      <br>Svi artikli prikazani na sajtu su deo nase ponude i ne podrazumeva da su dostupni u svakom trenutku. 
      </i></center>
      </div>
 <br>
  <p1><i><center><a href="/projekat/index.php">Kontakti ovlascenih servisa</a>&nbsp;|&nbsp;<a href="/projekat/index.php"">Uslovi koriscenja</a>&nbsp;|&nbsp;<a href="/projekat/index.php">Politika privatnosti</a>&nbsp;|&nbsp;<a href="/projekat/index.php">Zasto smo bolji od drugih</a>&nbsp;|&nbsp;<a href="/projekat/index.php">Posao</a>&nbsp;|&nbsp;
  <a href="//localhost/projekat/login/login.php"><font color="green">Login</font></a></i></p1>
 </div></center>
</div>

</body>
</html> 