<!DOCTYPE html>
<html>

<head>
	<link rel="icon" href="/projekat/slike/computer.png">
	<meta http-equiv="refresh" content="5;url=//localhost/projekat/index.php" />
	<title>Poruka nije poslata</title>
</head>

<body><center>
 <h2>Lose ste uneli parametre!<br></h2><br>
 <h2>Automatski cete biti vraceni na pocetnu stranicu. <br><br>
 	Ukoliko ne zelite da cekate kliknite link ispod.<br></h2> <br>
 <a href="//localhost/projekat/info/kontakt.php">Probaj ponovo</a><br><br><br>
 <a href="//localhost/projekat/index.php">Vrati se na sajt</a>
 </center>
</body>

</html>