<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="/projekat/slike/computer.png">
  <title>WhiTex Web Store</title>
  <link rel="stylesheet" type="text/css" href="//localhost/projekat/navigacijaGore.css" />
  <link rel="stylesheet" type="text/css" href="//localhost/projekat/info/izglednama.css" />
  <style type="text/css">
    a:hover, a:visited, a:link, a:active
    {
        text-decoration: none;
    }
  </style>
</head>

<body>

  <div id="slikaGore" align="center"><a href="/projekat/index.php">
<img align="center" src="/projekat/slike/header.jpg"></a>   </div>


 <center><div class="topnav" id="myTopnav"><b>
   <a href="/projekat/index.php">Pocetna</a>
   <a href="/projekat/konf/konf.php"><b>Kofigurator</b></a>
   <a href="/projekat/info/kontakt.php">Kontakt</a>
   <a class="active" href="/projekat/info/nama.php">O nama</a></b>

   <div class="vreme" align="right">
     <i><script type="text/javascript">
        var m_names = new Array("Januar", "Februar", "Mart", "April", "Maj", "Jun", "Jul", "Avgust", "Septembar", "Octobar", "Novembar", "Decembar");
        var d_names = new Array("Nedelja", "Ponedeljak", "Utorak", "Sreda", "Cetvrtak", "Petak", "Subota");
        
        var currentTime = new Date()
        var day = currentTime.getDay()
        var month = currentTime.getMonth() + 1
        var date = currentTime.getDate()
        var year = currentTime.getFullYear()
        document.write( d_names[day] + ", " + date + " " + m_names[month] + " " + year + ", ")
        var currentTime = new Date()
        var hours = currentTime.getHours()
        var minutes = currentTime.getMinutes()
        if (minutes < 10){
        minutes = "0" + minutes
        }
        document.write(hours + ":" + minutes + " ")
        if(hours > 11){
        document.write("PM &nbsp")
        } else {
        document.write("AM &nbsp")
        }
     </script></i>
   </div></center>
 </div>

 <center><div class="nama"> 
   <form action="dodajMejl.php">
     <div class="container">
       <h2>Sve o nama<br><br>
    
            <i>Na našem sajtu i u maloprodajama Vas očekuje širok asortiman racunarskih komponenti po neverovatnim cenama. 
            Whitex Web Store doo ponuda je ponuda koja će ispuniti očekivanja svakog gejmera kao i poslovnih i privatnih korisnika.
            <br>
            Whitex Web Store doo je uvek tu da vam obezbedi, uz odloženo plaćanje na više mesečnih rata, kao i vrhunski izbor proizvoda izuzetnog kvaliteta.
            <br>
            Stručnu pomoć za izbor najbolje konfiguracije za Vaše potrebe potražite od naših operatera putem kontakt forme.
            <br><br>
            NAŠ MOTO:

            Naše cene govore umesto nas.<br>
            <br><br>
            E-mail adresa: whitexkg@gmail.com</i></h2>
            <br><br>
            Ukoliko zelite da prvi budete obavesteni o svemu,<br>kao i da dobijate prvi 
            nase extra ponude i kataloge,<br> pretplatite se na nasu
            mail listu i budite jedan od <br>mnogobrojnih zadovoljnih kupaca.
      </div>
   <div class="container" style="background-color:white">
    <input type="text" id="Ime" name="Ime" minlength="1" maxlength="29" placeholder="Ime" required><br>
    <input type="Email" id="Email" name="Email" minlength="1" maxlength="39" placeholder="Email adresa" required><br>
    <input type="checkbox" id="Dnevni" name="Dnevni" checked="checked"> Dnevna obavestenja<br>
    <input type="submit" value="Posalji">
     <input type="reset"> 
   </div>
     </form>
 </div></center>
				

 <center><div class="futer" id="futer">

   <div class="social" align="left">

     <p1>Pratite nas</p1> <br><br>
     &nbsp&nbsp<a href="/projekat/index.php""><img src="/projekat/slike/social/instagram.png"></a>
     <a href="/projekat/index.php""><img src="/projekat/slike/social/facebook.png"></a>
     <a href="/projekat/index.php""><img src="/projekat/slike/social/google-plus.png"></a>
     <a href="/projekat/index.php""><img src="/projekat/slike/social/linkedin.png"></a>
     <a href="/projekat/index.php""><img src="/projekat/slike/social/twitter.png"></a>
     <a href="/projekat/index.php""><img src="/projekat/slike/social/youtube.png"></a>
   </div>

   <div class="placanje" align="right">
     <br>
     &nbsp&nbsp<a href="/projekat/index.php"><img src="/projekat/slike/placanje/maestro.png"></a>
     <a href="/projekat/index.php"><img src="/projekat/slike/placanje/mastercard.png"></a>
     <a href="/projekat/index.php"><img src="/projekat/slike/placanje/paypal.png"></a>
     <a href="/projekat/index.php"><img src="/projekat/slike/placanje/visa.png"></a>&nbsp&nbsp
    </div>

 <hr>

 <div class="sranje">
   <br><center><i>
   © 2018 WhiTex Web Store d.o.o. Sva prava zadrzana.<br>

   Cene na sajtu su iskazane u dinarima sa uracunatim porezom, a placanje se vrsi iskljucivo u dinarima.
   <br>Nastojimo da budemo sto precizniji u opisu proizvoda, prikazu slika i samih cena, ali ne mozemo garantovati da su sve informacije kompletne i bez gresaka.
   <br>Svi artikli prikazani na sajtu su deo nase ponude i ne podrazumeva da su dostupni u svakom trenutku. 
   </i></center>
  </div>

 <br>
 <p1><i><center><a href="/projekat/index.php">Kontakti ovlascenih servisa</a>&nbsp;|&nbsp;<a href="/projekat/index.php">Uslovi koriscenja</a>&nbsp;|&nbsp;<a href="/projekat/index.php">Politika privatnosti</a>&nbsp;|&nbsp;<a href="/projekat/index.php">Zasto smo bolji od drugih</a>&nbsp;|&nbsp;<a href="/projekat/index.php">Posao</a>&nbsp;|&nbsp;
 <a href="//localhost/projekat/login/login.php"><font color="green">Login</font></a></i></p1>
 </div></center>
    </div>
</body>
</html> 