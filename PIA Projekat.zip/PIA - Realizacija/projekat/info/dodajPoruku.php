<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projekat";

$conn = new mysqli($servername, $username, $password, $dbname);

if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
 }
 
$Ime = mysqli_real_escape_string($conn, $_REQUEST['Ime']);
$Prezime = mysqli_real_escape_string($conn, $_REQUEST['Prezime']);
$Drzava = mysqli_real_escape_string($conn, $_REQUEST['Drzava']);
$Grad = mysqli_real_escape_string($conn, $_REQUEST['Grad']);
$Adresa = mysqli_real_escape_string($conn, $_REQUEST['Adresa']);
$Email = mysqli_real_escape_string($conn, $_REQUEST['Email']);
$Svrha = mysqli_real_escape_string($conn, $_REQUEST['Svrha']);
$Poruka = mysqli_real_escape_string($conn, $_REQUEST['Poruka']);
$Datum = date("Y-m-d");

$sql = "INSERT INTO poruke (Ime, Prezime, Drzava, Grad, Adresa, Email, Svrha, Poruka, Datum) 
VALUES ('$Ime', '$Prezime', '$Drzava' , '$Grad' , '$Adresa' , '$Email', '$Svrha' , '$Poruka', '$Datum')";

if(mysqli_query($conn, $sql)){
    echo "Poruka poslata!";
    header('Location: index.php');
 } else{
    echo "Lose ste uneli parametre" . mysqli_error($conn);
    header('Location: index1.php');
     }
 
mysqli_close($conn);
?>