<!DOCTYPE html>
<html>
<head>
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="icon" href="/projekat/slike/computer.png">
 <title>WhiTex Web Store</title>
 <link rel="stylesheet" type="text/css" href="/projekat/navigacijaGore.css" />
 <link rel="stylesheet" type="text/css" href="/projekat/prodavnica/izgledProdavnica.css" />
 <style type="text/css">
   a:hover, a:visited, a:link, a:active
   {
    text-decoration: none;
   }
 </style>
</head>

<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projekat";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
 } 

?>

<?php
$sql1 = "SELECT * FROM hdd ORDER BY Cena ASC";
$result1 = $conn->query($sql1)->fetch_object();

$sql2 = "SELECT * FROM dvdrom ORDER BY Cena ASC";
$result2 = $conn->query($sql2)->fetch_object();

$sql3 = "SELECT * FROM vga ORDER BY Cena ASC";
$result3 = $conn->query($sql3)->fetch_object();

$sql4 = "SELECT * FROM hladnjaci ORDER BY Cena ASC";
$result4 = $conn->query($sql4)->fetch_object();

$sql5 = "SELECT * FROM kucista ORDER BY Cena ASC";
$result5 = $conn->query($sql5)->fetch_object();

$sql6 = "SELECT * FROM maticne ORDER BY Cena ASC";
$result6 = $conn->query($sql6)->fetch_object();

$sql7 = "SELECT * FROM napajanja ORDER BY Cena ASC";
$result7 = $conn->query($sql7)->fetch_object();

$sql8 = "SELECT * FROM procesori ORDER BY Cena ASC";
$result8 = $conn->query($sql8)->fetch_object();

$sql9 = "SELECT * FROM ram ORDER BY Cena ASC";
$result9 = $conn->query($sql9)->fetch_object();

$sql10 = "SELECT * FROM ssd ORDER BY Cena ASC";
$result10 = $conn->query($sql10)->fetch_object();
?> 


 <div id="slikaGore" align="center"><a href="/projekat/index.php">
 <img align="center" src="/projekat/slike/header.jpg"></a>
 </div>

 <center><div class="topnav" id="myTopnav">
   <b>
   <a href="/projekat/index.php">Pocetna</a>
   <a class="active" href="/projekat/konf/konf.php"><b>Konfigurator</b></a>
   <a href="/projekat/info/kontakt.php">Kontakt</a>
   <a href="/projekat/info/nama.php">O nama</a></b>
  <div class="vreme" align="right">
      <i><script type="text/javascript">
        var m_names = new Array("Januar", "Februar", "Mart", "April", "Maj", "Jun", "Jul", "Avgust", "Septembar", "Octobar", "Novembar", "Decembar");
        var d_names = new Array("Nedelja", "Ponedeljak", "Utorak", "Sreda", "Cetvrtak", "Petak", "Subota");
        
        var currentTime = new Date()
        var day = currentTime.getDay()
        var month = currentTime.getMonth() + 1
        var date = currentTime.getDate()
        var year = currentTime.getFullYear()
        document.write( d_names[day] + ", " + date + " " + m_names[month] + " " + year + ", ")
        var currentTime = new Date()
        var hours = currentTime.getHours()
        var minutes = currentTime.getMinutes()
        if (minutes < 10){
        minutes = "0" + minutes
        }
        document.write(hours + ":" + minutes + " ")
        if(hours > 11){
        document.write("PM &nbsp")
        } else {
        document.write("AM &nbsp")
        }
      </script></i>
        </div>
 </div>
 <br>
 <br>

 <div class="prikazKomponenti"><p>
 <?php 

 echo '<center><i><b>';
 echo "Izaberite zeljene komponente pomocu naseg 
 konfiguratora i mi cemo <br>za Vas ponuditi cenu sa popustom od 5% 
 ukoliko odlucite da ih kupite <br>kod nas u kompletu!<br><br></i>";
echo '</center></b><br>';


echo '<form action="konff.php">';

   $result1 = $conn->query($sql1);
echo '<label for="hdd">HDD</label>
      <select id="hdd" name="hdd" required>
      <option selected disabled hidden>&nbsp;</option>';
   if ($result1->num_rows > 0) {
     while($row = $result1->fetch_assoc()) {
echo "<option value=".$row["Cena"].">".$row["Proizvodjac"]."&nbsp".$row["Naziv"]."</option>";
      }}echo'</select><br><br>';


$result2 = $conn->query($sql2);
echo '<label for="dvd">DVD-ROM</label>
      <select id="dvd" name="dvd" required>
      <option selected disabled hidden>&nbsp;</option>';
   if ($result2->num_rows > 0) {
     while($row = $result2->fetch_assoc()) {
echo "<option value=".$row["Cena"].">".$row["Proizvodjac"]."&nbsp".$row["Naziv"]."</option>";
      }}echo'</select><br><br>';


$result3 = $conn->query($sql3);
echo '<label for="gpu">Graficka</label>
      <select id="gpu" name="gpu" required>
      <option selected disabled hidden>&nbsp;</option>';
   if ($result3->num_rows > 0) {
     while($row = $result3->fetch_assoc()) {
echo "<option value=".$row["Cena"].">".$row["Proizvodjac"]."&nbsp".$row["Naziv"]."</option>";
      }}echo'</select><br><br>';      


$result4 = $conn->query($sql4);
echo '<label for="kuler">Kuler</label>
      <select id="kuler" name="kuler" required>
      <option selected disabled hidden>&nbsp;</option>';
   if ($result4->num_rows > 0) {
     while($row = $result4->fetch_assoc()) {
echo "<option value=".$row["Cena"].">".$row["Proizvodjac"]."&nbsp".$row["Naziv"]."</option>";
      }}echo'</select><br><br>';


$result5 = $conn->query($sql5);
echo '<label for="box">Kuciste</label>
      <select id="box" name="box" required>
      <option selected disabled hidden>&nbsp;</option>';
   if ($result5->num_rows > 0) {
     while($row = $result5->fetch_assoc()) {
echo "<option value=".$row["Cena"].">".$row["Proizvodjac"]."&nbsp".$row["Naziv"]."</option>";
      }}echo'</select><br><br>'; 


$result6 = $conn->query($sql6);
echo '<label for="mb">Maticna Ploca</label>
      <select id="mb" name="mb" required>
      <option selected disabled hidden>&nbsp;</option>';
   if ($result6->num_rows > 0) {
     while($row = $result6->fetch_assoc()) {
echo "<option value=".$row["Cena"].">".$row["Proizvodjac"]."&nbsp".$row["Naziv"]."</option>";
      }}echo'</select><br><br>'; 
 

 $result7 = $conn->query($sql7);
echo '<label for="pwr">Napajanje</label>
      <select id="pwr" name="pwr" required>
      <option selected disabled hidden>&nbsp;</option>';
   if ($result7->num_rows > 0) {
     while($row = $result7->fetch_assoc()) {
echo "<option value=".$row["Cena"].">".$row["Proizvodjac"]."&nbsp".$row["Naziv"]."</option>";
      }}echo'</select><br><br>'; 


$result8 = $conn->query($sql8);
echo '<label for="cpu">Procesor</label>
      <select id="cpu" name="cpu" required>
      <option selected disabled hidden>&nbsp;</option>';
   if ($result8->num_rows > 0) {
     while($row = $result8->fetch_assoc()) {
echo "<option value=".$row["Cena"].">".$row["Proizvodjac"]."&nbsp".$row["Naziv"]."</option>";
      }}echo'</select><br><br>';       
 

$result9 = $conn->query($sql9);
echo '<label for="ram">RAM</label>
      <select id="ram" name="ram" required>
      <option selected disabled hidden>&nbsp;</option>';
   if ($result9->num_rows > 0) {
     while($row = $result9->fetch_assoc()) {
echo "<option value=".$row["Cena"].">".$row["Proizvodjac"]."&nbsp".$row["Naziv"]."</option>";
      }}echo'</select><br><br>'; 
 

$result10 = $conn->query($sql10);
echo '<label for="ssd">SSD</label>
      <select id="ssd" name="ssd" required>
      <option selected disabled hidden>&nbsp;</option>';
   if ($result10->num_rows > 0) {
     while($row = $result10->fetch_assoc()) {
echo "<option value=".$row["Cena"].">".$row["Proizvodjac"]."&nbsp".$row["Naziv"]."</option>";
      }}echo'</select><br><br>'; 


      echo "<br>";
      echo '<input type="submit" value="Izracunaj"></p>
      <p>
      <input type="reset"></p>';
      echo '</form>';
 ?>   
 </p></div>

 <br>

 <center><div class="futer" id="futer">

   <div class="social" align="left">

      <p1>Pratite nas</p1> <br><br>
       &nbsp&nbsp<a href="/projekat/index.php""><img src="/projekat/slike/social/instagram.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/facebook.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/google-plus.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/linkedin.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/twitter.png"></a>
       <a href="/projekat/index.php""><img src="/projekat/slike/social/youtube.png"></a>
     </div>

    <div class="placanje" align="right">
      <br>
      &nbsp&nbsp<a href="/projekat/index.php"><img src="/projekat/slike/placanje/maestro.png"></a>
      <a href="/projekat/index.php"><img src="/projekat/slike/placanje/mastercard.png"></a>
      <a href="/projekat/index.php"><img src="/projekat/slike/placanje/paypal.png"></a>
      <a href="/projekat/index.php"><img src="/projekat/slike/placanje/visa.png"></a>&nbsp&nbsp
      </div>

 <hr>

<div class="sranje">
   <br><center><i>
    © 2018 WhiTex Web Store d.o.o. Sva prava zadrzana.<br>

    Cene na sajtu su iskazane u dinarima sa uracunatim porezom, a placanje se vrsi iskljucivo u dinarima.
    <br>Nastojimo da budemo sto precizniji u opisu proizvoda, prikazu slika i samih cena, ali ne mozemo garantovati da su sve informacije kompletne i bez gresaka.
    <br>Svi artikli prikazani na sajtu su deo nase ponude i ne podrazumeva da su dostupni u svakom trenutku. 
    </i></center>
 </div>

 <br>
 <p1><i><center><a href="/projekat/index.php">Kontakti ovlascenih servisa</a>&nbsp;|&nbsp;<a href="/projekat/index.php"">Uslovi koriscenja</a>&nbsp;|&nbsp;<a href="/projekat/index.php">Politika privatnosti</a>&nbsp;|&nbsp;<a href="/projekat/index.php">Zasto smo bolji od drugih</a>&nbsp;|&nbsp;<a href="/projekat/index.php">Posao</a>&nbsp;|&nbsp;
 <a href="//localhost/projekat/login/login.php"><font color="green">Login</font></a></i></p1>
 </div></center>
    
</body>
</html> 