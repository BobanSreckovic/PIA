<?php
session_start();
$x="Admin";
if ($_SESSION["privilegija"] == $x) {echo '<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/projekat/slike/computer.png">
	<meta charset="UTF-8">
	<title>Dodaj Proizvod</title>
</head>

<body>
		<center>
			<a href="cp.php">Nazad na CP</a>
			<br><br><br>
			<a href="dodajProizvodHDD.php">HDD</a>
			<br><br>
			<a href="dodajProizvodDVD.php">DVD ROM</a>
			<br><br>
			<a href="dodajProizvodGPU.php">Graficka kartica</a>
			<br><br>
			<a href="dodajProizvodCOOL.php">Kuler</a>
			<br><br>
			<a href="dodajProizvodBOX.php">Kuciste</a>
			<br><br>
			<a href="dodajProizvodMB.php">Maticna ploca</a>
			<br><br>
			<a href="dodajProizvodPWR.php">Napajanje</a>
			<br><br>
			<a href="dodajProizvodCPU.php">Procesor</a>
			<br><br>
			<a href="dodajProizvodRAM.php">RAM</a>
			<br><br>
			<a href="dodajProizvodSSD.php">SSD</a>
			<br><br>
	    </center>
</body>
</html>';}else{header('Location: index.php');}
?>