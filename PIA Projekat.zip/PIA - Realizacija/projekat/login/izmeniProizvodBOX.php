<?php
session_start();
$x="Admin";
if ($_SESSION["privilegija"] == $x) {echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Izmeni Kuciste</title>
</head>

<body>
     <center> 
       <form action="izmeniBOX.php" method="post">;';

              $servername = "localhost";
              $username = "root";
              $password = "";
              $dbname = "projekat";

              $conn = new mysqli($servername, $username, $password, $dbname);
              // Check connection
              if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                 } 

              echo '<a href="cp.php">Nazad na CP</a>';
              echo '<br>';
              echo '<a href="izmeniPro.php">Nazad na stranicu za izmenu proizvoda</a>';
              echo '<br>';
              echo '<br>';
echo'

           <p>
      <label for="nazivKomp">Naziv</label>
      <input type="text" name="naziv" id="naziv">
     </p>

<p>
      <label for="proizvodjac">Proizvodjac</label>
      <input type="text" name="proizvodjac" id="proizvodjac">
     </p>

     <p>
             <label for="cena">Cena</label>
             <input type="text" name="cena" id="cena">
           </p>

     <p>
      <label for="format">Format</label>
      <select id="format" name="format" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="Midi Tower">Midi Tower</option>
        <option value="ATX Tower">ATX Tower</option>
      </select>
     </p>
           <p>
            <label for="kolicina">Kolicina</label>
            <input type="text" name="kolicina" id="kolicina">
           </p>';

               $sql = "SELECT IDBOX,Naziv FROM kucista";

               $result = $conn->query($sql);

               if ($result->num_rows > 0) {
                   while($row = $result->fetch_assoc()) {
                	   echo '<br>';
                     echo "Naziv: " . $row["Naziv"] . "&nbsp;  &nbsp;  &nbsp;";
                     echo '<input type="radio" name="IDBOX" value="' . $row["IDBOX"] . '. "&nbsp;  &nbsp;  &nbsp;">';
                 }
                  } else {
                     echo "Nema proizvoda";
               }
echo'

           <br><br><br>
           <input type="submit" value="Izmeni Kuciste">
        </form>
     </center>
 </body>
</html>';}else{header('Location: index.php');}
?>