<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "projekat";

$x="Admin";
if ($_SESSION["privilegija"] == $x) {


 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
     } 

 echo'<center><a href="izmeniPro.php">Nazad na stranicu za izmenu proizvoda</a><br></center>';
 echo'<center><a href="izmeniProizvodHDD.php">Nazad na stranicu za izmenu HDD</a><br><br></center>';

 $Naziv = mysqli_real_escape_string($conn, $_REQUEST['naziv']);
 $Proizvodjac = mysqli_real_escape_string($conn, $_REQUEST['proizvodjac']);
 $Cena = mysqli_real_escape_string($conn, $_REQUEST['cena']);
 $Tip = mysqli_real_escape_string($conn, $_REQUEST['tip']);
 $Povezivanje = mysqli_real_escape_string($conn, $_REQUEST['povezivanje']);
 $Kapacitet = mysqli_real_escape_string($conn, $_REQUEST['kapacitet']);
 $Kolicina = mysqli_real_escape_string($conn, $_REQUEST['kolicina']);
 $IDHDD = mysqli_real_escape_string($conn, $_REQUEST['IDHDD']);

 $sql = "UPDATE hdd SET Naziv='$Naziv', Proizvodjac='$Proizvodjac' ,
 Cena='$Cena', Tip='$Tip', Povezivanje='$Povezivanje' ,
 Kapacitet='$Kapacitet' , Kolicina='$Kolicina' WHERE IDHDD=$IDHDD";

 if ($conn->query($sql) === TRUE) {
     echo "<center>Podaci za HDD uspesno promenjeni!</center>";
     } else {
         echo "<center>Lose ste uneli podatke</center>" . $conn->error;
           }

 $conn->close();}else{header('Location: index.php');}
?>