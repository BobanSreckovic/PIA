<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "projekat";

$x="Admin";
if ($_SESSION["privilegija"] == $x) {


 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
     } 

 echo'<center><a href="ukloniPro.php">Nazad na stranicu za uklanjanje proizvoda</a><br><br></center>';

 $IDCOOL = mysqli_real_escape_string($conn, $_REQUEST['IDCOOL']);

 $sql = "DELETE FROM hladnjaci WHERE IDCOOL=$IDCOOL";

 if ($conn->query($sql) === TRUE) {
     echo "<center>Hladnjak uspesno obrisan!</center>";
     } else {
          echo "<center>Lose ste uneli podatke</center>" . $conn->error;
     }

 $conn->close();}else{header('Location: index.php');}
?>