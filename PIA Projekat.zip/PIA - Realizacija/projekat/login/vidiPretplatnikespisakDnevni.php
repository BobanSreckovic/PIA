<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "projekat";

$x="Admin";
if ($_SESSION["privilegija"] == $x) {

 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
   } 
 echo '<center>';
 echo '<a href="cp.php">Nazad na CP</a>';
 echo '<br>';
 echo '<a href="vidiPretplatnike.php">Nazad na spisak svih pretplatnike</a>';
 echo '<br>';
 echo '<a href="dnevnaPretplata.php">Nazad na spisak dnevnih pretplatnika</a>';
 echo '<br>';
 echo '<br>';
?>

<?php
 $sql1 = "SELECT * FROM listamail";
 $result1 = $conn->query($sql1)->fetch_object();
 $result1 = $conn->query($sql1);
 $x="on";

   if ($result1->num_rows > 0) {
     while($row = $result1->fetch_assoc()) {
       if ($row["Dnevni"] == $x) {
         echo $row["Email"];
         echo '<br>';
       }}}else{
        echo "Nema trazenih parametara.";
      }echo '</center>';
}else{header('Location: index.php');}
?>   