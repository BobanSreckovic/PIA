<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "projekat";

$x="Admin";
if ($_SESSION["privilegija"] == $x) {


 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
     } 

 echo'<center><a href="izmeniPro.php">Nazad na stranicu za izmenu proizvoda</a><br></center>';
 echo'<center><a href="izmeniProizvodMB.php">Nazad na stranicu za izmenu Maticne</a><br><br></center>';

 $Naziv = mysqli_real_escape_string($conn, $_REQUEST['naziv']);
 $Proizvodjac = mysqli_real_escape_string($conn, $_REQUEST['proizvodjac']);
 $Cena = mysqli_real_escape_string($conn, $_REQUEST['cena']);
 $Format = mysqli_real_escape_string($conn, $_REQUEST['format']);
 $Slot = mysqli_real_escape_string($conn, $_REQUEST['slot']);
 $Kolicina = mysqli_real_escape_string($conn, $_REQUEST['kolicina']);
 $IDMB = mysqli_real_escape_string($conn, $_REQUEST['IDMB']);

 $sql = "UPDATE maticne SET Naziv='$Naziv', Proizvodjac='$Proizvodjac' ,
 Cena='$Cena', Format='$Format', Slot='$Slot', Kolicina='$Kolicina' WHERE IDMB=$IDMB";

 if ($conn->query($sql) === TRUE) {
     echo "<center>Podaci za Maticnu uspesno promenjeni!</center>";
     } else {
         echo "<center>Lose ste uneli podatke</center>" . $conn->error;
           }

 $conn->close();}else{header('Location: index.php');}
?>