<?php
session_start();
$x="Admin";
if ($_SESSION["privilegija"] == $x) {echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Obrisi poruku</title>
</head>

<body>
 <center>
   <form action="obrisiPoruku.php" method="post">';
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "projekat";

        $conn = new mysqli($servername, $username, $password, $dbname);
        
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
          } 

          echo '<a href="cp.php">Nazad na CP</a>';
          echo '<br>';
          echo '<a href="vidiPoruke.php">Pregled svih poruka</a>';
          echo '<br>';

        $sql = "SELECT IDporuke,Ime,Prezime,Svrha,Poruka FROM poruke";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
            echo '<br>';
            echo "Ime i prezime: " . $row["Ime"] . $row["Prezime"] . "&nbsp;  &nbsp;  &nbsp;";
            echo '<br>';
            echo "Svrha poruke: " . $row["Svrha"] . "&nbsp;  &nbsp;  &nbsp;";
            echo '<br>';
            echo "Poruka: " . $row["Poruka"] . "&nbsp;  &nbsp;  &nbsp;";
            echo '<br>';
            echo '<input type="radio" name="IDporuke" value="' . $row["IDporuke"] . '. "&nbsp;  &nbsp;  &nbsp;">';
            echo '<br>';
              }
             } else {
                 echo "Nema poruka za brisanje.";
           }
echo'
       <br><br>
       <input type="submit" value="Obrisi poruku">
     </form>
   </center>
</body>
</html>';}else{header('Location: index.php');}
?>