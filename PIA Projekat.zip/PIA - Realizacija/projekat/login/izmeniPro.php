<?php
session_start();
$x="Admin";
if ($_SESSION["privilegija"] == $x) {echo '<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/projekat/slike/computer.png">
	<meta charset="UTF-8">
	<title>Izmeni Proizvod</title>
</head>

<body>
	 <center> 
			<a href="cp.php">Nazad na CP</a>
			<br><br><br>
			<a href="izmeniProizvodHDD.php">HDD</a>
			<br><br>
			<a href="izmeniProizvodDVD.php">DVD ROM</a>
			<br><br>
			<a href="izmeniProizvodGPU.php">Graficka kartica</a>
			<br><br>
			<a href="izmeniProizvodCOOL.php">Kuler</a>
			<br><br>
			<a href="izmeniProizvodBOX.php">Kuciste</a>
			<br><br>
			<a href="izmeniProizvodMB.php">Maticna ploca</a>
			<br><br>
			<a href="izmeniProizvodPWR.php">Napajanje</a>
			<br><br>
			<a href="izmeniProizvodCPU.php">Procesor</a>
			<br><br>
			<a href="izmeniProizvodRAM.php">RAM</a>
			<br><br>
			<a href="izmeniProizvodSSD.php">SSD</a>
			<br><br>
     </center>
</body>
</html>';}else{header('Location: index.php');}
?>