<?php
session_start();
$x="Admin";
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "projekat";

 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
   } 

   if ($_SESSION["privilegija"] == $x) {
  echo '<center>';
  echo '<a href="cp.php">Nazad na CP</a>';
  echo '<br>';
  echo '<a href="vidiPretplatnike.php">Nazad na spisak svih pretplatnike</a>';
  echo '<br>';
  echo '<a href="vidiPretplatnikespisakDnevni.php">Spisak Email adresa (samo dnevni)</a>';
  echo '<br>';

 $sql1 = "SELECT * FROM listamail";
 $result1 = $conn->query($sql1)->fetch_object();
 $result1 = $conn->query($sql1);
 $x="on";

  if ($result1->num_rows > 0) {
    while($row = $result1->fetch_assoc()) {
      if ($row["Dnevni"] == $x) {
    	 echo "<hr>";
       echo "Ime korisnika: " . $row["Ime"]. "<br>";
       echo "Email korisnika: " . $row["Email"] . "<br>";
       echo "Datum: " . $row["Datum"] . "<br>";
      }}}else{
        echo "Nema dnevnih pretplata.";
      }echo '</center>';
    }else{header('Location: index.php');}
?>   