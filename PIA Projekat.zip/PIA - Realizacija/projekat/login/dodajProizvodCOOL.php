<?php
session_start();
$x="Admin";
if ($_SESSION["privilegija"] == $x) {echo '
    <!DOCTYPE html>
    <html lang="en">
    <head>
     <link rel="icon" href="/projekat/slike/computer.png">
     <meta charset="UTF-8">
     <title>Dodaj novi Kuler</title>
    </head>

 <body>
     <center>
         <a href="cp.php">Nazad na CP</a>
         <br><br>
         <a href="dodajPro.php">Nazad na dodavanje novih proizvoda</a>
         <br><br><br>
         <form action="dodajCOOL.php" method="post" enctype="multipart/form-data">
             <p>
             	<label for="Naziv">Naziv:</label>
                <input type="text" name="naziv" id="naziv" required>
             </p>
             <p>
                <label for="Proizvodjac">Proizvodjac:</label>
                <input type="text" name="proizvodjac" id="proizvodjac" required>
             </p>
             <p>
                <label for="Cena">Cena:</label>
                <input type="text" name="cena" id="cena" required>
             </p>
             <p>
                <label for="komp">Kompatibilnost:</label>
                <input type="text" name="komp" id="komp" required>
             </p>
             <p>
                <label for="Kolicina">Kolicina:</label>
                <input type="text" name="kolicina" id="kolicina" required>
             </p>
             <p>
                <label for="Slika">Slika:</label>
                <input type="file" name="fileToUpload" id="fileToUpload"><br><br>
             </p>

             <input type="submit" value="Dodaj Kuler">
            </form>
    </center>
 </body>
 </html>';
 }else{
     header('Location: index.php');
     }
?>