<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "projekat";

$x="Admin";
if ($_SESSION["privilegija"] == $x) {


 $conn = new mysqli($servername, $username, $password, $dbname);

 if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
     }

 $Ime = mysqli_real_escape_string($conn, $_REQUEST['ime']);
 $Prezime = mysqli_real_escape_string($conn, $_REQUEST['prezime']);
 $Drzava = mysqli_real_escape_string($conn, $_REQUEST['drzava']);
 $Svrha = mysqli_real_escape_string($conn, $_REQUEST['svrha']);

 echo "<center>";
 echo '<a href="cp.php">Nazad na CP</a>';
 echo '<br>';
 echo '<a href="vidiPoruke.php">Vidi sve poruke</a>';
 echo "</center>";
?>

<?php
 $sql1 = "SELECT * FROM poruke WHERE Ime LIKE '%$Ime%' AND Prezime LIKE '%$Prezime%' AND Drzava LIKE '%$Drzava%' AND Svrha LIKE '%$Svrha%'";
 $result1 = $conn->query($sql1)->fetch_object();
 $result1 = $conn->query($sql1);
   
  if ($result1->num_rows > 0) {
     while($row = $result1->fetch_assoc()) {
       echo "<center>";
    	 echo "<hr>";
       echo "Ime korisnika: " . $row["Ime"]. "<br>";
       echo "Prezime korisnika: " . $row["Prezime"] . "<br>";
       echo "Drzava: " . $row["Drzava"] . "<br>";
       echo "Grad: " . $row["Grad"] . "<br>";
         echo "Adresa: " . $row["Adresa"] . "<br>";
         echo "Svrha: " . $row["Svrha"] . "<br>";
       echo "Datum: " . $row["Datum"] . "<br><br>";
       echo "Poruka: <br>" . $row["Poruka"] . "<br>";
       echo "<br>";
       }}else{
        echo "<center>";
        echo "<br>";
        echo "Nema trazenih parametara.";
      }echo "</center>";}else{header('Location: index.php');}
 ?>   