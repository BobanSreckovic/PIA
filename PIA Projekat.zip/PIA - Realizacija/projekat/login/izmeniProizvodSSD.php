<?php
session_start();
$x="Admin";
if ($_SESSION["privilegija"] == $x) {echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Izmeni SSD</title>
</head>

<body>
     <center> 
       <form action="izmeniSSD.php" method="post">';

              $servername = "localhost";
              $username = "root";
              $password = "";
              $dbname = "projekat";

              $conn = new mysqli($servername, $username, $password, $dbname);
              // Check connection
              if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                 } 

              echo '<a href="cp.php">Nazad na CP</a>';
              echo '<br>';
              echo '<a href="izmeniPro.php">Nazad na stranicu za izmenu proizvoda</a>';
              echo '<br>';
              echo '<br>';

echo'
 <p>
      <label for="nazivKomp">Naziv</label>
      <input type="text" name="naziv" id="naziv">
     </p>

     <p>
      <label for="proizvodjac">Proizvodjac</label>
      <input type="text" name="proizvodjac" id="proizvodjac">
     </p>

      <p>
             <label for="cena">Cena</label>
             <input type="text" name="cena" id="cena">
           </p>
    
     <p>
      <label for="povezivanje">Povezivanje</label>
      <select id="povezivanje" name="povezivanje" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="SATA3"> SATA3 </option>
      </select>
     </p>
        
     <p>
      <label for="kapacitet">Kapacitet</label>
      <select id="kapacitet" name="kapacitet" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="240GB"> 240GB </option>
        <option value="256GB"> 256GB </option>
        <option value="275GB"> 275GB </option>
        <option value="480GB"> 480GB </option>
        <option value="2TB"> 2TB </option>
        <option value="4TB"> 4TB </option>
      </select>
     </p>
           <p>
            <label for="kolicina">Kolicina</label>
            <input type="text" name="kolicina" id="kolicina">
           </p>';

               $sql = "SELECT IDSSD,Naziv FROM ssd";

               $result = $conn->query($sql);

               if ($result->num_rows > 0) {
                   while($row = $result->fetch_assoc()) {
                	   echo '<br>';
                     echo "Naziv: " . $row["Naziv"] . "&nbsp;  &nbsp;  &nbsp;";
                     echo '<input type="radio" name="IDSSD" value="' . $row["IDSSD"] . '. "&nbsp;  &nbsp;  &nbsp;">';
                 }
                  } else {
                     echo "Nema proizvoda";
               }
echo'

           <br><br><br>
           <input type="submit" value="Izmeni SSD">
        </form>
     </center>
 </body>
</html>';}else{header('Location: index.php');}
?>