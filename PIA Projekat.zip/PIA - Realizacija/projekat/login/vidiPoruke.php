<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "projekat";

$x="Admin";
if ($_SESSION["privilegija"] == $x) {

 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
     } 

  echo '<center>';
  echo '<a href="cp.php">Nazad na CP</a>';
  echo '<br>';
  echo '<a href="brisanjePoruka.php">Brisanje poruka</a>';
  echo '<br>';
  echo '<form action="vidiPorukePretraga.php">

   <p>
      <label for="ime">Ime korisnika</label><br>
      <input type="text" name="ime" id="ime" required>
   </p>
   <p>
      <label for="prezime">Prezime korisnika</label><br>
      <input type="text" name="prezime" id="prezime" required>
   </p>
   <p>
      <label for="drzava">Drzava korisnika</label><br>
      <input type="text" name="drzava" id="drzava" required>
   </p>
   <p>
      <label for="svrha">Svrha poruke</label><br>
      <input type="text" name="svrha" id="svrha" required>
   </p>
   <p>
     <input type="submit" value="Pretraga"></p>
    </form>';
 ?>

<?php
 $sql1 = "SELECT * FROM poruke";
 $result1 = $conn->query($sql1)->fetch_object();
 $result1 = $conn->query($sql1);

   if ($result1->num_rows > 0) {
       while($row = $result1->fetch_assoc()) {
    	   echo "<hr>";
         echo "Ime korisnika: " . $row["Ime"]. "<br>";
         echo "Prezime korisnika: " . $row["Prezime"] . "<br>";
         echo "Drzava: " . $row["Drzava"] . "<br>";
         echo "Grad: " . $row["Grad"] . "<br>";
         echo "Adresa: " . $row["Adresa"] . "<br>";
         echo "Svrha: " . $row["Svrha"] . "<br>";
         echo "Datum: " . $row["Datum"] . "<br><br>";
         echo "Poruka: <br>" . $row["Poruka"] . "<br>";
         echo "<br>";        
       }}else{
        echo "Nema poruka za prikaz.";
      }echo '</center>';
}else{header('Location: index.php');}      
 ?>   