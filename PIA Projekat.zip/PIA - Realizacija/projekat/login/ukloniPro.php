<?php
session_start();
$x="Admin";
if ($_SESSION["privilegija"] == $x) {echo '<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/projekat/slike/computer.png">
	<meta charset="UTF-8">
	<title>Ukloni Proizvod</title>
</head>

<body>
	<center> 
		<a href="cp.php">Nazad na CP</a>
		<br><br><br>
		<a href="ukloniProizvodHDD.php">HDD</a>
		<br><br>
		<a href="ukloniProizvodDVD.php">DVD ROM</a>
		<br><br>
		<a href="ukloniProizvodGPU.php">Graficka kartica</a>
		<br><br>
		<a href="ukloniProizvodCOOL.php">Kuler</a>
		<br><br>
		<a href="ukloniProizvodBOX.php">Kuciste</a>
		<br><br>
		<a href="ukloniProizvodMB.php">Maticna ploca</a>
		<br><br>
		<a href="ukloniProizvodPWR.php">Napajanje</a>
		<br><br>
		<a href="ukloniProizvodCPU.php">Procesor</a>
		<br><br>
		<a href="ukloniProizvodRAM.php">RAM</a>
		<br><br>
		<a href="ukloniProizvodSSD.php">SSD</a>
		<br><br>
	</center>
</body>
</html>';}
else{
	header('Location: index.php');
}
?>