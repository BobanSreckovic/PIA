<!DOCTYPE html>
<html>
<head>
 <link rel="icon" href="/projekat/slike/computer.png">
 <title>Login stranica</title>
 <link rel="stylesheet" type="text/css" href="/projekat/login/loginCSS.css" />
</head>

<body>
 <center><form action="loginProvera.php" method="post">
   <h2>Korisnicko ime:</h2><input type="text" name="ime"><br>
   <h2>Lozinka:</h2><input type="password" name="sifra"><br>
   <br>
   <input type="submit" value ="Log In">
    <input type="reset" value ="Reset">
 </form></center>
 <center>
 	<br><br><br><b>
 <a href="//localhost/projekat/index.php"> Nazad na sajt. </a></b></center>
</body>
</html>