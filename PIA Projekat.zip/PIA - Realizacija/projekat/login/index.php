<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="/projekat/slike/computer.png">
	<title>Pogresan unos</title>
</head>

<body>
	<center>
		<h2>Pogresno ste uneli pristupne parametre<br></h2><br>
		<a href="//localhost/projekat/index.php">Vrati se na sajt</a><br><br><br>
		<a href="//localhost/projekat/login/login.php">Probaj ponovo unos parametara za pristup</a>
	</center>
</body>
</html>