<?php
session_start();
$x="Admin";
if ($_SESSION["privilegija"] == $x) {echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Izmeni Graficku</title>
</head>

<body>
     <center> 
       <form action="izmeniGPU.php" method="post">';

              $servername = "localhost";
              $username = "root";
              $password = "";
              $dbname = "projekat";

              $conn = new mysqli($servername, $username, $password, $dbname);
              // Check connection
              if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                 } 

              echo '<a href="cp.php">Nazad na CP</a>';
              echo '<br>';
              echo '<a href="izmeniPro.php">Nazad na stranicu za izmenu proizvoda</a>';
              echo '<br>';
              echo '<br>';
echo'

           <p>
      <label for="nazivKomp">Naziv</label>
      <input type="text" name="naziv" id="naziv">
     </p>

       <p>
             <label for="proizvodjac">Proizvodjac</label>
             <input type="text" name="proizvodjac" id="proizvodjac">
           </p>

      <p>
             <label for="cena">Cena</label>
             <input type="text" name="cena" id="cena">
           </p>
    
     <p>
      <label for="memmagistrala">Memorijska magistrala</label>
      <select id="memmagistrala" name="memmagistrala" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="ATA"> 32-bit </option>
        <option value="SATA2"> 64-bit </option>
        <option value="SATA3"> 128-bit </option>
        <option value="USB2.0"> 256-bit </option>
      </select>
     </p>
        
     <p>
      <label for="memorija">Memorija</label>
      <select id="memorija" name="memorija" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="1GB"> 1GB </option>
        <option value="2GB"> 2GB </option>
        <option value="4GB"> 4GB </option>
        <option value="8GB"> 8GB </option>
      </select>
     </p>

     <p>
      <label for="tipmemorije">Tip memorije</label>
      <select id="tipmemorije" name="tipmemorije" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="DDR3"> DDR3 </option>
        <option value="GDDR5"> GDDR5 </option>
      </select>
     </p>

     <p>
      <label for="slotovi">Slotovi</label>
      <select id="slotovi" name="slotovi" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="PCI-Express 2.0"> PCI-Express 2.0 </option>
        <option value="PCI-Express 3.0"> PCI-Express 3.0 </option>
      </select>
     </p>
           <p>
            <label for="kolicina">Kolicina</label>
            <input type="text" name="kolicina" id="kolicina">
           </p>';

               $sql = "SELECT IDVGA,Naziv FROM vga";

               $result = $conn->query($sql);

               if ($result->num_rows > 0) {
                   while($row = $result->fetch_assoc()) {
                	   echo '<br>';
                     echo "Naziv: " . $row["Naziv"] . "&nbsp;  &nbsp;  &nbsp;";
                     echo '<input type="radio" name="IDVGA" value="' . $row["IDVGA"] . '. "&nbsp;  &nbsp;  &nbsp;">';
                 }
                  } else {
                     echo "Nema proizvoda";
               }
               echo'

           <br><br><br>
           <input type="submit" value="Izmeni Graficku">
        </form>
     </center>
 </body>
</html>';}else{header('Location: index.php');}
?>