<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "projekat";

$x="Admin";
if ($_SESSION["privilegija"] == $x) {

 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
   } 
 echo '<center>';
 echo '<a href="cp.php">Nazad na CP</a>';
 echo '<br>';
 echo '<a href="dnevnaPretplata.php">Dnevni pretplatnici</a>';
 echo '<br>';
 echo '<a href="vidiPretplatnikespisak.php">Spisak Email adresa (svi Pretplatnici)</a>';
 echo '<br>';
 echo '<a href="brisanjePretplatnika.php">Uklanjanje pretplatnika</a>';
 echo '<br>';
 ?>

<?php
 $sql1 = "SELECT * FROM listamail";
 $result1 = $conn->query($sql1)->fetch_object();
 $result1 = $conn->query($sql1);
 $x="on";

  if ($result1->num_rows > 0) {
    while($row = $result1->fetch_assoc()) {
    	  echo "<hr>";
        echo "Ime korisnika: " . $row["Ime"]. "<br>";
        echo "Email korisnika: " . $row["Email"] . "<br>";
        if ($row["Dnevni"] == $x) {
            echo "Prijavio se za dnevna obavestenja: " . $row["Dnevni"] . "<br>";
           }
        echo "Datum: " . $row["Datum"] . "<br><br>";
        echo "<br>";
       }}else{
        echo "Nema trazenih parametara.";
      }echo '</center>';
 }else{header('Location: index.php');}
 ?>   