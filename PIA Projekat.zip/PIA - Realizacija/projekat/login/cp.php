<?php
session_start();
$x="Admin";
if ($_SESSION["privilegija"] == $x) {echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/projekat/slike/computer.png">
	<meta charset="UTF-8">
	<title>Admin Control Panel</title>
</head>

<body>
		<center><a href="dodajPro.php">Dodaj novi proizvod</a>
			<br><br>
			<a href="ukloniPro.php">Ukloni vec postojeci proizvod</a><br><br>

			<a href="izmeniPro.php">Izmeni specifikacije proizvoda</a>
			<br><br>

			<a href="vidiPoruke.php">Procitaj sve poruke korisnika</a><br><br>

			<a href="vidiPretplatnike.php">Korisnici pretplatnici</a><br><br><br>
			<a href="//localhost/projekat/index.php">Povratak na sajt</a>
	    </center>
</body>
</html>';}else{
	echo '<center>';
	echo '<br><b>';
	echo 'Molimo Vas da prvo idete na <a href="//localhost/projekat/login/login.php">Login stranicu</a> i tamo unesete validne pristupne parametre!';
	echo '<br>';
	echo '<a href="/projekat/index.php"><b>Nazad na sajt.</b></a>';
	echo '</b>';
	echo '</center>';
}
?>