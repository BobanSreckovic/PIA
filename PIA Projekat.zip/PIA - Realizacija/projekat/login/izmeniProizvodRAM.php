<?php
session_start();
$x="Admin";
if ($_SESSION["privilegija"] == $x) {echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Izmeni RAM</title>
</head>

<body>
     <center> 
       <form action="izmeniRAM.php" method="post">';

              $servername = "localhost";
              $username = "root";
              $password = "";
              $dbname = "projekat";

              $conn = new mysqli($servername, $username, $password, $dbname);
              // Check connection
              if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                 } 

              echo '<a href="cp.php">Nazad na CP</a>';
              echo '<br>';
              echo '<a href="izmeniPro.php">Nazad na stranicu za izmenu proizvoda</a>';
              echo '<br>';
              echo '<br>';
echo'

 <p>
      <label for="nazivKomp">Naziv</label>
      <input type="text" name="naziv" id="naziv">
     </p>

      <p>
      <label for="proizvodjac">Proizvodjac</label>
      <input type="text" name="proizvodjac" id="proizvodjac">
     </p>

        <p>
             <label for="cena">Cena</label>
             <input type="text" name="cena" id="cena">
           </p>

     <p>
      <label for="tip">Tip</label>
      <select id="tip" name="tip" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="DDR2">DDR2</option>
        <option value="DDR3">DDR3</option>
        <option value="DDR4">DDR4</option>
      </select>
     </p>
    
     <p>
      <label for="takt">Takt</label>
      <select id="takt" name="takt" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="667MHz"> 667MHz </option>
        <option value="1333MHz"> 1333MHz </option>
        <option value="1600MHz"> 1600MHz </option>
        <option value="1866MHz"> 1866MHz </option>
        <option value="2400MHz"> 2400MHz </option>
        <option value="3000MHz"> 3000MHz </option>
      </select>
     </p>
        
   <p>
      <label for="latencija">Latencija</label>
      <select id="latencija" name="latencija" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="667MHz"> CL5 </option>
        <option value="1333MHz"> CL9 </option>
        <option value="1600MHz"> CL10 </option>
        <option value="1866MHz"> CL15 </option>
        <option value="2400MHz"> CL16 </option>
      </select>
     </p>

     <p>
      <label for="kapacitet">Kapacitet</label>
      <select id="kapacitet" name="kapacitet" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="1GB"> 1GB </option>
        <option value="2GB"> 2GB </option>
        <option value="4GB"> 4GB </option>
        <option value="8GB"> 8GB </option>
        <option value="16GB"> 16GB </option>
      </select>
     </p>
           <p>
            <label for="kolicina">Kolicina</label>
            <input type="text" name="kolicina" id="kolicina">
           </p>';

               $sql = "SELECT IDRAM,Naziv FROM ram";

               $result = $conn->query($sql);

               if ($result->num_rows > 0) {
                   while($row = $result->fetch_assoc()) {
                	   echo '<br>';
                     echo "Naziv: " . $row["Naziv"] . "&nbsp;  &nbsp;  &nbsp;";
                     echo '<input type="radio" name="IDRAM" value="' . $row["IDRAM"] . '. "&nbsp;  &nbsp;  &nbsp;">';
                 }
                  } else {
                     echo "Nema proizvoda";
               }
echo'

           <br><br><br>
           <input type="submit" value="Izmeni RAM">
        </form>
     </center>
 </body>
</html>';}else{header('Location: index.php');}
?>