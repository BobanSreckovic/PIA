<?php
 session_start();
 $x="Admin";
 if ($_SESSION["privilegija"] == $x) {echo '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="icon" href="/projekat/slike/computer.png">
        <meta charset="UTF-8">
        <title>Dodaj novi RAM</title>
    </head>

 <body>
     <center>
         <a href="cp.php">Nazad na CP</a>
         <br><br>
         <a href="dodajPro.php">Nazad na dodavanje novih proizvoda</a>
         <br><br><br>
         <form action="dodajRAM.php" method="post" enctype="multipart/form-data">
             <p>
             	<label for="Naziv">Naziv:</label>
                <input type="text" name="naziv" id="naziv" required>
             </p>
             <p>
                <label for="Proizvodjac">Proizvodjac:</label>
                <input type="text" name="proizvodjac" id="proizvodjac" required>
             </p>
             <p>
                <label for="Cena">Cena:</label>
                <input type="text" name="cena" id="cena" required>
             </p>
             <p>
                <label for="tip">Tip:</label>
                <input type="text" name="tip" id="tip" required>
             </p>
             <p>
                <label for="kapacitet">Kapacitet:</label>
                <input type="text" name="kapacitet" id="kapacitet" required>
             </p>
              <p>
                <label for="brzinarada">BrzinaRada:</label>
                <input type="text" name="brzinarada" id="brzinarada" required>
             </p>
              <p>
                <label for="latencija">Latencija:</label>
                <input type="text" name="latencija" id="latencija" required>
             </p>
             <p>
                <label for="Kolicina">Kolicina:</label>
                <input type="text" name="kolicina" id="kolicina" required>
             </p>
             <p>
                <label for="Slika">Slika:</label>
                <input type="file" name="fileToUpload" id="fileToUpload"><br><br>
             </p>

             <input type="submit" value="Dodaj RAM">
            </form>
    </center>
 </body>
 </html>';
 }else{
     header('Location: index.php');
     }
?>