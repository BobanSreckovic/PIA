<?php
session_start();
$x="Admin";
if ($_SESSION["privilegija"] == $x) {
echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Obrisi pretplatnika</title>
</head>

<body>
 <center>
   <form action="obrisiPretplatnika.php" method="post">';
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "projekat";

        $conn = new mysqli($servername, $username, $password, $dbname);
        
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
          } 

          echo'<a href="cp.php">Nazad na CP</a>';
          echo'<br>';
          echo'<a href="vidiPretplatnike.php">Pregled svih pretplatnika</a>';
          echo'<br>';
        $sql = "SELECT IDmail,Ime,Email FROM listamail";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
            echo '<br>';
            echo "Ime: " . $row["Ime"] . "<br>";
            echo "Email: " . $row["Email"] . "<br>";
            echo '<input type="radio" name="IDmail" value="' . $row["IDmail"] . '. "&nbsp;  &nbsp;  &nbsp;">';
            echo '<br>';
              }
             } else {
                 echo "Nema pretplatnika";
           }
echo '
       <br><br>
       <input type="submit" value="Obrisi pretplatnika">
     </form>
   </center>
</body>
</html>';
}else{header('Location: index.php');}
?>