<?php 
    session_start();
    $myFile = "sifre.txt";
    $contents = file_get_contents($myFile);
    $contents = explode("\n", $contents);
    $error = "Username ili sifra nisu dobri";
    $jaoIme = $_POST['ime'];
    $jaoSifra = $_POST['sifra'];
    $ip = getHostByName(getHostName());

 foreach($contents as $values){
     $loginInfo = explode(":", $values);
     $user = $loginInfo[0];
     $password = $loginInfo[1];

     if($user == $_POST['ime'] && $password == $_POST['sifra']){
        $_SESSION["privilegija"] = "Admin";
        header('Location: cp.php');
     }
     else{
         $f = fopen("errorLog.txt", "a");
         fwrite($f, $jaoIme); 
         fwrite($f, " : "); 
         fwrite($f, $jaoSifra);
         fwrite($f, " : "); 
         fwrite($f, $ip . "\r\n");
         fclose($f);
         $f = fopen("errorLog.txt", "r");
         fclose($f);
         echo $error;
         echo '<script>alert("Nije dobro");</script>';
         sleep(1);
         header('Location: index.php');
     }
 }
?>