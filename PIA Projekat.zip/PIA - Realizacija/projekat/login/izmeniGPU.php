<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "projekat";

$x="Admin";
if ($_SESSION["privilegija"] == $x) {


 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
     } 

 echo'<center><a href="izmeniPro.php">Nazad na stranicu za izmenu proizvoda</a><br></center>';
 echo'<center><a href="izmeniProizvodGPU.php">Nazad na stranicu za izmenu Graficke</a><br><br></center>';

 $Naziv = mysqli_real_escape_string($conn, $_REQUEST['naziv']);
 $Proizvodjac = mysqli_real_escape_string($conn, $_REQUEST['proizvodjac']);
 $Cena = mysqli_real_escape_string($conn, $_REQUEST['cena']);
 $MemMagistrala = mysqli_real_escape_string($conn, $_REQUEST['memmagistrala']);
 $Slotovi = mysqli_real_escape_string($conn, $_REQUEST['slotovi']);
 $Memorija = mysqli_real_escape_string($conn, $_REQUEST['memorija']);
 $TipMem = mysqli_real_escape_string($conn, $_REQUEST['tipmemorije']);
 $Kolicina = mysqli_real_escape_string($conn, $_REQUEST['kolicina']);
 $IDVGA = mysqli_real_escape_string($conn, $_REQUEST['IDVGA']);

 $sql = "UPDATE vga SET Naziv='$Naziv', Proizvodjac='$Proizvodjac' ,
 Cena='$Cena', MemMagistrala='$MemMagistrala', Slotovi='$Slotovi',
 Memorija='$Memorija', TipMem='$TipMem', Kolicina='$Kolicina' WHERE IDVGA=$IDVGA";

 if ($conn->query($sql) === TRUE) {
     echo "<center>Podaci za Grafikcu uspesno promenjeni!</center>";
     } else {
         echo "<center>Lose ste uneli podatke</center>" . $conn->error;
           }

 $conn->close();}else{header('Location: index.php');}
?>