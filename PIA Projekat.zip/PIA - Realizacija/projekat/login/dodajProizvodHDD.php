<?php
 session_start();
 $x="Admin";
 if ($_SESSION["privilegija"] == $x) {echo '
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <link rel="icon" href="/projekat/slike/computer.png">
     <meta charset="UTF-8">
     <title>Dodaj novi HDD</title>
    </head>

 <body>
     <center>
         <a href="cp.php">Nazad na CP</a>
         <br><br>
         <a href="dodajPro.php">Nazad na dodavanje novih proizvoda</a>
         <br><br><br>
         <form action="dodajHDD.php" method="post" enctype="multipart/form-data">
             <p>
             	<label for="Naziv">Naziv:</label>
                <input type="text" name="naziv" id="naziv" required>
             </p>
             <p>
                <label for="Proizvodjac">Proizvodjac:</label>
                <input type="text" name="proizvodjac" id="proizvodjac" required>
             </p>
             <p>
                <label for="Cena">Cena:</label>
                <input type="text" name="cena" id="cena" required>
             </p>
             <p>
                <label for="Tip">Tip:</label>
                <input type="text" name="tip" id="tip" required>
             </p>
             <p>
                <label for="Povezivanje">Povezivanje:</label>
                <input type="text" name="povezivanje" id="povezivanje" required>
             </p>
             <p>
                <label for="Kapacitet">Kapacitet:</label>
                <input type="text" name="kapacitet" id="kapacitet" required>
             </p>
             <p>
                <label for="Format">Format:</label>
                <input type="text" name="format" id="format" required>
             </p>
                <p>
                <label for="Kolicina">Kolicina:</label>
                <input type="text" name="kolicina" id="kolicina" required>
             </p>
             <p>
                <label for="Slika">Slika:</label>
                <input type="file" name="fileToUpload" id="fileToUpload"><br><br>
             </p>

             <input type="submit" value="Dodaj HDD">
            </form>
    </center>
 </body>
 </html>';
 }else{
     header('Location: index.php');
     }
?>