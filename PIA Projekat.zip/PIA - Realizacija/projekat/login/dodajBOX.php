<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "projekat";

$x="Admin";
if ($_SESSION["privilegija"] == $x) {

 echo'<center><a href="dodajPro.php">Nazad na dodavanje novih proizvoda</a><br><br></center>';
     
 $conn = new mysqli($servername, $username, $password, $dbname);
 
 if($conn === false){
     die("ERROR: Could not connect. " . mysqli_connect_error());
     }


 $Naziv = mysqli_real_escape_string($conn, $_REQUEST['naziv']);
 $Proizvodjac = mysqli_real_escape_string($conn, $_REQUEST['proizvodjac']);
 $Cena = mysqli_real_escape_string($conn, $_REQUEST['cena']);
 $Format = mysqli_real_escape_string($conn, $_REQUEST['format']);
 $Kolicina = mysqli_real_escape_string($conn, $_REQUEST['kolicina']);

 $sql = "INSERT INTO kucista (Naziv, Proizvodjac, Cena, Format, Kolicina) 
    VALUES ('$Naziv', '$Proizvodjac', '$Cena', '$Format', '$Kolicina')";

 if(mysqli_query($conn, $sql)){
        echo "<center>Kuciste uspesno dodata!</center>";
     } else{
         echo "<center>Lose ste uneli podatke</center>" . mysqli_error($conn);
     }
 
 // OVO NIJE MOJE - GOTOV KOD ZA UPLOAD

 $target_dir = "jao/";
 $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
 $uploadOk = 1;
 $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    // Check if image file is a actual image or fake image
    if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if($check !== false) {
            echo "<center>Fajl je slika - " . $check["mime"] . ".</center>";
            $uploadOk = 1;
        } else {
            echo "<center>Fajl nije slika.</center>";
            $uploadOk = 0;
        }
    }
    // Check if file already exists
    if (file_exists($target_file)) {
        echo "<center>Fajl postoji!.</center>";
        $uploadOk = 0;
    }
    // Check file size
    if ($_FILES["fileToUpload"]["size"] > 1000000) {
        echo "<center>Fajl je prevelik.</center>";
        $uploadOk = 0;
    }
    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        echo "<center>Samo JPG, JPEG, PNG & GIF ekstenzije fajla su dozvoljene.</center>";
        $uploadOk = 0;
    }
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "<center>Fajl nije uploadovan.</center>";
    // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            echo "<center>Fajl ". basename( $_FILES["fileToUpload"]["name"]). " je uploadovan.</center>";
            $pictureName = "jao/". basename( $_FILES["fileToUpload"]["name"]);

    $sql1 = "UPDATE kucista SET Slika='$pictureName' WHERE Naziv='$Naziv'";
    // Make Sure to tell MySQL which user you want to update which means setting the variable $myEmail and $myPassword accordingly

    if ($conn->query($sql1) === TRUE) {
        echo "<center>Uspesno dodavanje</center>";
    } else {
        echo "<center>Greska pri dodavanju: </center>" . $conn->error;
    }

        } else {
            echo "<center>Greska prilikom upload fajla.</center>";
        }
    }

 mysqli_close($conn);}else{
    header('Location: index.php');
        }
?>