<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "projekat";

$x="Admin";
if ($_SESSION["privilegija"] == $x) {

 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
     } 
 echo'<center><a href="brisanjePretplatnika.php">Nazad na stranicu za uklanjanje pretplatnika</a><br><br></center>';

 $IDmail = mysqli_real_escape_string($conn, $_REQUEST['IDmail']);

 $sql = "DELETE FROM listamail WHERE IDmail=$IDmail";

 if ($conn->query($sql) === TRUE) {
     echo "<center>Pretplatnik uspesno uklonjen!</center>";
     } else {
         echo "<center>Lose ste uneli podatke</center>" . $conn->error;
     }

 $conn->close();}else{header('Location: index.php');}
?>