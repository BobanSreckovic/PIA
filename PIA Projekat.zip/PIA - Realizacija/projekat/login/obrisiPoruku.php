<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "projekat";

$x="Admin";
if ($_SESSION["privilegija"] == $x) {

 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
     } 
 echo'<center><a href="brisanjePoruka.php">Nazad na stranicu za uklanjanje poruka</a><br><br></center>';

 $IDporuke = mysqli_real_escape_string($conn, $_REQUEST['IDporuke']);

 $sql = "DELETE FROM poruke WHERE IDporuke=$IDporuke";

 if ($conn->query($sql) === TRUE) {
     echo "<center>Poruka uspesno obrisana!</center>";
     } else {
         echo "<center>Lose ste uneli podatke</center>" . $conn->error;
     }

 $conn->close();}else{header('Location: index.php');}
?>