<?php
session_start();
$x="Admin";
if ($_SESSION["privilegija"] == $x) {echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Izmeni Napajanje</title>
</head>

<body>
     <center> 
       <form action="izmeniPWR.php" method="post">';

              $servername = "localhost";
              $username = "root";
              $password = "";
              $dbname = "projekat";

              $conn = new mysqli($servername, $username, $password, $dbname);
              // Check connection
              if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                 } 

              echo '<a href="cp.php">Nazad na CP</a>';
              echo '<br>';
              echo '<a href="izmeniPro.php">Nazad na stranicu za izmenu proizvoda</a>';
              echo '<br>';
              echo '<br>';
echo'


 <p>
      <label for="nazivKomp">Naziv</label>
      <input type="text" name="naziv" id="naziv">
     </p>

      <p>
      <label for="proizvodjac">Proizvodjac</label>
      <input type="text" name="proizvodjac" id="proizvodjac">
     </p>

       <p>
             <label for="cena">Cena</label>
             <input type="text" name="cena" id="cena">
           </p>

 <p>
             <label for="snaga">Snaga</label>
             <input type="text" name="snaga" id="snaga">
           </p>

           <p>
            <label for="kolicina">Kolicina</label>
            <input type="text" name="kolicina" id="kolicina">
           </p>';

               $sql = "SELECT IDPWR,Naziv FROM napajanja";

               $result = $conn->query($sql);

               if ($result->num_rows > 0) {
                   while($row = $result->fetch_assoc()) {
                	   echo '<br>';
                     echo "Naziv: " . $row["Naziv"] . "&nbsp;  &nbsp;  &nbsp;";
                     echo '<input type="radio" name="IDPWR" value="' . $row["IDPWR"] . '. "&nbsp;  &nbsp;  &nbsp;">';
                 }
                  } else {
                     echo "Nema proizvoda";
               }
echo'

           <br><br><br>
           <input type="submit" value="Izmeni Napajanje">
        </form>
     </center>
 </body>
</html>';}else{header('Location: index.php');}
?>