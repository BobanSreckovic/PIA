<?php
session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "projekat";

$x="Admin";
if ($_SESSION["privilegija"] == $x) {


 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
     } 

 echo'<center><a href="izmeniPro.php">Nazad na stranicu za izmenu proizvoda</a><br></center>';
 echo'<center><a href="izmeniProizvodCPU.php">Nazad na stranicu za izmenu CPU</a><br><br></center>';

 $Naziv = mysqli_real_escape_string($conn, $_REQUEST['naziv']);
 $Proizvodjac = mysqli_real_escape_string($conn, $_REQUEST['proizvodjac']);
 $Cena = mysqli_real_escape_string($conn, $_REQUEST['cena']);
 $Slot = mysqli_real_escape_string($conn, $_REQUEST['slot']);
 $Takt = mysqli_real_escape_string($conn, $_REQUEST['takt']);
 $Kolicina = mysqli_real_escape_string($conn, $_REQUEST['kolicina']);
 $IDCPU = mysqli_real_escape_string($conn, $_REQUEST['IDCPU']);

 $sql = "UPDATE procesori SET Naziv='$Naziv', Proizvodjac='$Proizvodjac' ,
 Cena='$Cena', Slot='$Slot', Takt='$Takt', Kolicina='$Kolicina' WHERE IDCPU=$IDCPU";

 if ($conn->query($sql) === TRUE) {
     echo "<center>Podaci za CPU uspesno promenjeni!</center>";
     } else {
         echo "<center>Lose ste uneli podatke</center>" . $conn->error;
           }

 $conn->close();}else{header('Location: index.php');}
?>